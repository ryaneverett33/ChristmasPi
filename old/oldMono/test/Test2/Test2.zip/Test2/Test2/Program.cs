﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using WiringPi;

namespace Test2 {
    class Program {
        static void Main(string[] args) {
            Init.WiringPiSetup();
            GPIO.pinMode(7, (int)GPIO.GPIOpinmode.Output);
            Thread.Sleep(1000);
            Console.WriteLine("Attempting to turn on GPIO");
            GPIO.digitalWrite(7, 1);
            Thread.Sleep(1000);
            Console.WriteLine("Attemtping to turn off GPIO");
            Thread.Sleep(500);
        }
    }
}
