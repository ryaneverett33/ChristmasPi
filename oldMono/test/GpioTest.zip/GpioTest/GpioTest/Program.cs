﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using Server;

namespace GpioTest {
    class Program {
        static void Main(string[] args) {
            Gpio gpio = new Gpio();
            Animations animations = new Animations(gpio);
            animations.flash();
            animations.twinkle();
            animations.twinkle();
            animations.twinkle();
            animations.staircase();
        }
    }
}
